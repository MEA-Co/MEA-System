# 학습법 개편 운영 적용 절차

## 현재 상태와 기록 구분

- 2026-10-15 운영 사전 점검에서 `20261013085231_study_query_contract.sql`이 여전히 대기 중임을 읽기 전용으로 확인했다. 이번 조회 변경은 기존 학습법 데이터/저장 함수를 변경하지 않는다. 비교 기준 `203e7ee`의 임시저장 코드로 만든 가상 초안을 현재 코드로 읽어 본문·참고자료·ID·revision·localVersion·첨부 메타데이터/원문 보존을 확인했고, 학습법 저장 회귀 20개와 편집 복구 검사 3개가 통과했다. 실제 사용자 브라우저 데이터는 확인하지 않았다. **질문지의 시작 안내 이전 문제는 보존 이전으로 수정·로컬 검증했다. 열린 구형 응답 화면 문제는 사용자 결정에 따라 코드 수정 없이 작성자가 없는 새벽 전환으로 대응**하며 [최종 사전 점검](../questions/operations.md#최종-사전-점검-2026-10-15)을 먼저 따른다. 운영 쓰기/앱 배포는 하지 않았다.
- `20261012024650_study_solution_fields.sql`은 [질문 운영 기록](../questions/operations.md)의 2026-10-12 등록 안내 카드 적용 기록에서 운영 반영을 확인했다. 아래 최초 적용 절차의 당시 미적용 표현을 현재 상태로 해석하거나 재적용하지 않는다.
- `20261013085231_study_query_contract.sql`은 로컬 적용·검증 완료, 운영 미적용이다. 다음 적용은 아래 **조회 구조 정리 적용 (2026-10-13)** 절을 따른다.
- 문서 정리 중 운영 DB를 새로 조회하거나 변경하지 않았다. 실제 배포 직전 연결 대상과 migration 이력을 다시 확인한다.

## 최초 솔루션 개편 적용 기록과 데이터 보존

예상 프로젝트: `epwlcallocdjkmgdmtlv`.
예상 migration: **`20261012024650_study_solution_fields.sql` 한 개**.
2026-10-12 확인 당시 운영 최신 이력은 `20261012011802`이며 dry-run에 위 파일만 표시됐다. 운영에는 아직 적용하지 않았다.

마이그레이션은 한 트랜잭션에서 다음을 수행한다.

1. 기존 저장 함수 해시가 `712012985cb0d8e2b7321198e6967ebc`인지 검사한다. 예상 밖 수정이 있으면 중단한다.
2. 쓰기를 잠시 잠근 뒤 모든 학습법 행을 `private.study_solution_backup_20261012`에 원형 그대로 보관한다. 일반 사용자·서비스 역할은 이 백업 테이블을 읽을 수 없다.
3. 활성 행에 경험 `''`, 기간 설정 `true`를 추가하고 출처 `student`를 `self`로 통합한다. 문제·전략·기간·체크리스트·기존 진단·첨부·ID·소유자·생성 시각을 유지한다. 삭제된 행은 변경하지 않는다.
4. 활성 행의 revision을 1 올리고 save ID·수정 시각을 갱신해 배포 전 편집본이 덮어쓰지 못하게 한다.
5. 조건부 기간 필수 검사, 경험 저장, 기존 클라이언트의 새 필드 생략 호환을 제공하는 저장 함수를 교체한다. 기존 역할·RLS·Storage 정책은 변경하지 않는다.

체크리스트는 문자열/줄바꿈 형식을 그대로 사용하므로 배열로 변환하거나 원문을 다시 생성하지 않는다. 기존 서술형 문제 상황도 임의로 요약하지 않는다. 현재 56개 템플릿은 앱 코드에 있고 기존 작성 내용을 덮어쓰지 않는다.

## 1. 작업 시간 확보와 백업

배포 동안 학습법 작성·저장을 중지하도록 사용자에게 안내하고 편집 탭을 닫는다. 새 필드가 추가되므로 **DB 적용 후 구버전 앱을 장시간 운영하지 않는다**. DB 적용과 새 앱 배포를 같은 작업 시간에 진행한다.

미저장 작성 내용은 별도로 복사한다. 브라우저 임시저장은 서버 백업 대상이 아니므로 localStorage/IndexedDB를 지우지 않는다. 특히 확정본을 수정하던 임시저장은 기존 revision이어서 적용 후 충돌할 수 있다. 최신 확정본을 다시 열고 보관한 변경분을 옮겨 저장한다. 오래된 revision을 강제로 덮어쓰지 않는다.

프로젝트와 이력 확인:

```bash
cd /Users/mealdm/Desktop/MEA/system
cat supabase/.temp/project-ref
npx supabase projects list
npx supabase migration list --linked
npx supabase db push --linked --dry-run --skip-vault
```

프로젝트 ID를 Dashboard와 대조한다. **예상과 다른 migration이 나오면 적용하지 말고 먼저 이력을 검토한다.** `--include-all`, 원격 reset, `migration repair`로 우회하지 않는다.

Dashboard에서 최근 백업/PITR 복구 가능 시점을 확인한다. 추가로 저장 경로를 Git 저장소 밖에 만들고 schema와 data를 내보낸다. 아래는 public/private 전체 백업이며 개인정보가 포함되므로 공유하거나 커밋하지 않는다. CLI dump는 로컬 Docker가 필요하다.

```bash
umask 077
MEA_STUDY_BACKUP_DIR="$HOME/MEA-backups/study-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$MEA_STUDY_BACKUP_DIR"
npx supabase db dump --linked --schema public,private --file "$MEA_STUDY_BACKUP_DIR/schema.sql"
npx supabase db dump --linked --schema public,private --data-only --use-copy --file "$MEA_STUDY_BACKUP_DIR/data.sql"
test -s "$MEA_STUDY_BACKUP_DIR/schema.sql" && test -s "$MEA_STUDY_BACKUP_DIR/data.sql"
```

덤프 완료 여부와 `public.study` 데이터 포함 여부를 확인한 뒤 진행한다. 이 덤프는 Storage 파일 원본이나 auth 전체 복구용 백업이 아니다. 이번 작업은 파일을 삭제하지 않으며 전체 복구는 Dashboard 백업/PITR 정책과 함께 준비한다.

SQL Editor에서 `supabase/verification/study_solution_preflight.sql`을 실행하고 집계 결과를 기록한다. 함수 해시가 위 값과 같아야 하며 `unexpected_new_fields`는 0이어야 한다. 달라졌다면 중단하고 검토한다. 현재 관측치 1건을 고정 전제로 적용하지 않는다.

## 2. 실제 DB 적용

백업·쓰기 중지·dry-run 확인이 끝났을 때만:

```bash
npx supabase db push --linked --skip-vault
npx supabase migration list --linked
npx supabase db push --linked --dry-run --skip-vault
```

적용 파일은 위 한 개, 적용 후 대기는 없어야 한다. `--skip-vault`는 무관한 Vault 설정 동기화를 방지한다. lock timeout이 나면 트랜잭션이 롤백되므로 진행 중인 쓰기와 이력을 확인한 뒤 재시도한다. 파일 내부의 BEGIN/COMMIT을 제거하지 않는다.

아직 사용자 쓰기를 재개하지 말고 SQL Editor에서 `supabase/verification/study_solution_postflight.sql`을 실행한다.

- backup_rows: 사전 전체 행 수와 동일
- mismatched_rows: **0** (본문·파일·소유자·생성 시각 및 예상 revision 포함 비교)
- invalid_active_rows: **0**
- save_hash: **`907172de62fb8f1e438e9833d5a1921d`**
- public_backup_grants: **0**

새 쓰기가 시작된 후에는 snapshot과 달라지는 것이 정상이다. 이 전체 비교는 배포 직후 쓰기를 재개하기 전에 실행한다.

## 3. 앱 배포와 확인

```bash
npm run build -- --webpack
```

검증된 변경을 기존 운영 배포 파이프라인으로 배포한다. 이 저장소에서 위 build 명령만 실행하는 것은 운영 배포가 아니다. 서버·브라우저 모두 새 버전을 사용하도록 새로고침한다.

운영에서 작성자 계정으로 다음을 확인한 후 쓰기를 재개한다.

- 기존 학습법 1건 이상의 문제·전략·체크리스트·기간 내용과 소유자가 유지되는지
- 출처가 통합 선택지로 표시되고, 템플릿 목록이 20개이며 제외한 두 항목 및 과목 공통 4개가 없는지
- 경험 입력 저장 → 새로고침 → 상세/수정에서 유지되는지
- 기간 체크 해제·빈 기간으로 저장, 재조회 후 해제 상태 유지, 다시 체크하면 기간 필수 검사되는지
- 체크리스트 항목 추가·삭제·수정 후 재조회 시 항목이 유지되는지
- 기존 @학습법 참조가 같은 ID의 학습법을 여전히 여는지
- 타인의 학습법 수정 불가, 자신의 학습법 수정 가능
- 삭제한 UI 항목의 과거 데이터·첨부 파일이 DB/Storage에서 유지되는지

이 단계는 사용자가 수행할 실제 기능 확인이며 에이전트가 브라우저에서 확인한 것으로 간주하지 않는다.

## 4. 이상 발생 시

쓰기 재개를 멈추고 오류·대상 ID·현재 revision을 기록한다. UI 문제만이라도 구버전 앱을 무조건 배포하지 않는다. 구버전의 strict schema가 추가 필드를 거부할 수 있다.

마이그레이션 실행 실패는 동일 트랜잭션에서 롤백된다. 이력과 함수 해시를 확인하고 원인을 해결한 뒤 다시 적용한다. 이미 성공한 migration을 삭제하거나 repair로 미적용 처리하지 않는다.

성공 후 문제가 발견되면 **수정 migration으로 전진 복구하는 것을 우선**한다. 원본은 private 백업에 있으며 SQL Editor 관리자만 특정 ID의 `row_data`를 조회해 비교할 수 있다. 백업에서 일괄 UPDATE하거나 전체 dump를 운영에 바로 복원하면 배포 후 작성한 데이터를 잃을 수 있다.

되돌리기가 꼭 필요하면 먼저 현재 데이터·경험·기간 설정과 신규 작성 행도 별도로 백업한다. 수정 여부를 revision으로 비교하고, 변경된 행은 기존 snapshot으로 덮어쓰지 않는다. DB 함수와 앱의 읽기/쓰기 형식을 함께 맞추는 별도 rollback migration을 리뷰한 후 적용한다. PITR은 전체 서비스의 이후 변경까지 되돌리므로 학습법 단건 문제의 기본 복구 수단으로 사용하지 않는다.

private 백업 테이블은 기능 확인과 보존 기간 합의가 끝날 때까지 유지한다. 자동 삭제 작업은 만들지 않았다.

## 로컬 회귀 재실행

migration 적용 전의 로컬 DB에서는 `node scripts/verify-study-migration.mjs`로 가상 기존 데이터의 이전 보존을 시험하고 전부 롤백한다. 이미 적용된 로컬 DB에서는 기존 함수 해시 검사로 중단하는 것이 정상이며 재시험 목적으로 운영/로컬 데이터를 reset하지 않는다.

```bash
node --test scripts/verify-study-templates.mjs
MEA_TEST_BLOCK=study node --test scripts/verify-exploration-storage.mjs scripts/verify-question-study.mjs
docker exec -i supabase_db_system psql -U postgres -d postgres -v ON_ERROR_STOP=1 < supabase/tests/study_solution_fields.sql
docker exec -i supabase_db_system psql -U postgres -d postgres -v ON_ERROR_STOP=1 < supabase/tests/study_storage.sql
docker exec -i supabase_db_system psql -U postgres -d postgres -v ON_ERROR_STOP=1 < supabase/tests/study_guide_reference.sql
```

공식 참고: [Supabase migration 관리](https://supabase.com/docs/guides/deployment/database-migrations).

## 조회 구조 정리 적용 (2026-10-13)

이번 변경은 `20261013085231_study_query_contract.sql` 한 개다.
read_study_page/read_study_summary 조회 함수와 실행 권한만 추가하며, 기존 행·저장 함수·삭제 함수는 변경하지 않는다.
앞 절의 데이터 이전/백업 절차는 과거 solution_fields migration 전용이며 이번 조회 함수 추가 때문에 재실행하지 않는다.

로컬 DB에 적용했고 조회 SQL 회귀는 가상 데이터로 실행한 뒤 롤백했다.
운영 조회/쓰기와 앱 배포는 하지 않았다. 실제 적용은 다른 디자인 변경과 함께 최종 배포 시 진행한다.

1. 프로젝트 경로와 연결된 운영 대상을 확인한다.

```bash
cd /Users/mealdm/Desktop/MEA/system
cat supabase/.temp/project-ref
npx supabase migration list --linked
```

연결된 대상이 의도한 운영 프로젝트인지 확인한다. 현재 저장소 연결 참조는 epwlcallocdjkmgdmtlv다.
출력이 다르거나 이력이 어긋나면 적용하지 말고 검토한다.

2. 적용 예정 파일을 확인한다.

```bash
npx supabase db push --linked --dry-run
```

이번 추가 파일은 20261013085231_study_query_contract.sql이다.
다른 미적용 migration도 나오면 기존 운영 이력·각 변경의 승인/검증 상태를 먼저 확인한다.
예상과 다르다고 include-all/repair/reset으로 강제 진행하지 않는다.

3. 대상·예정 파일 검토 후 적용하고, 대기 없음과 이력을 확인한다.

```bash
npx supabase db push --linked
npx supabase migration list --linked
npx supabase db push --linked --dry-run
```

4. 앱을 검증하고 기존 운영 배포 파이프라인으로 배포한다. build만으로 배포되지는 않는다.

```bash
npm run typecheck
npm run build -- --webpack
```

DB 함수를 먼저 적용해야 새 앱의 목록 RPC 호출이 성공한다.
운영 배포 파이프라인의 실행은 기존 프로젝트 절차를 따른다.

5. 운영 앱에서 본인/타인 목록, 검색·다음 페이지, 임시저장 통합, 확정 필터의 삭제 대상,
질문 @ 선택·학습법 첨부의 다음 페이지 및 선택 유지, 큰 입력의 오류 안내를 확인한다.
학생/비로그인 접근 차단과 컨설턴트 타인 목록 차단도 확인한다.

로컬 조회 회귀 재실행:

```bash
docker exec -i supabase_db_system psql -U postgres -d postgres -v ON_ERROR_STOP=1 < supabase/tests/study_queries.sql
node scripts/verify-study-pagination.mjs --local
```

## 질문 독립 첨부형 제거 (2026-10-14)

질문 유형 폐기 및 기존 답변의 본문 참조 전환 migration 두 개를 로컬에 적용했다. 도메인 원본·파일은 삭제하지 않는다. 운영 미적용이며 전체 개선 완료 후 [질문 운영 문서](../questions/operations.md#독립-첨부형-제거와-본문-참조-전환-2026-10-14)의 사전 점검·적용·앱 배포 순서를 따른다.

## 업무 충돌 무한 재시도 수정 (2026-10-16)

저장·삭제 함수의 업무 충돌을 SQLSTATE `PGRST` / HTTP 409 / JSON code `40001`로 전달하도록 로컬과 운영에 적용했다. 데이터·권한·revision 검사는 유지한다. 운영에는 공통 긴급 수정 SQL만 실행했고 다른 대기 migration·앱 배포는 진행하지 않았다. 정확한 적용 이력과 다음 배포 순서는 [질문 운영 문서](../questions/operations.md#업무-충돌-무한-재시도-긴급-수정-2026-10-16)에 모은다.

## 로딩 UI 검증 (2026-10-19)

회원 관리 서버 조회 대기, 질문지 가이드 답변 조회, 학습법·탐구활동 첨부 선택 목록의 로딩 UI를 보완했다. 타입 검사·변경 파일 린트·관련 회귀 8개·Webpack 프로덕션 빌드 통과. DB migration·API·권한 변경은 없으며 실제 브라우저 테스트와 운영 배포는 수행하지 않았다.

### 첨부 로딩 보완·가이드 표시 복원 (2026-10-19)

선택기 진입 전 사용자 확인과 참조 상세 Drawer의 문구형 로딩도 스켈레톤으로 교체했다. 가이드 답변의 추가 로딩/오류 UI는 사용자 요청으로 제거하고 기존 데이터가 있을 때만 표시하도록 복원했다. 이번 보완의 타입 검사·변경 파일 린트·첨부 선택 회귀 2개 통과. 실제 브라우저 테스트·운영 배포는 수행하지 않았다.

## 참조 중 학습법·탐구활동 삭제 차단 (2026-10-19)

Migration: `20261019083549_protect_referenced_learning_materials.sql`. 로컬 적용·검증 완료, 운영 DB와 앱 배포는 미수행이다. 수정은 허용하며 삭제 시 DB 참조 검사만 추가한다. 동시 참조 저장 보호 트리거도 함께 적용한다. 스캔/잠금 비용과 범위는 데이터·API 문서의 최신 삭제 보호 계약을 따른다.

검증:
- `supabase/tests/learning_material_delete_protection.sql`: 모든 7개 저장 원본, 비공개 응답/RLS, 최종 제출본만 남은 경우, 변경 허용, 참조 제거 후 삭제, UUID 오탐 방지, 삭제 후 신규 참조 거절, helper ACL. 가상 데이터 전체 롤백. 생성된 최종 migration도 관련 객체만 재생하는 롤백 트랜잭션에서 같은 회귀 통과.
- `python3 scripts/verify-material-delete-concurrency.py`: 로컬 Docker 전용, 두 자료 각각 저장 우선/삭제 우선 4개 경쟁 검증 통과. 임의 UUID의 가상 fixture를 만들고 finally에서 정리한다.
- `node --test scripts/verify-material-delete-api.mjs`: HTTP409/메시지/기존 권한·충돌 응답과 차단 시 파일 정리 미실행 8개 통과.
- 기존 business_conflict_transport, response_integrity_and_submission_reads, review_live_layout SQL 통과. 기존 study_storage/exploration_activity_storage는 과거 serialization_failure 기대를 현재 PGRST/JSON40001 검사로 바꾼 임시 사본으로 통과(저장소의 구형 테스트는 미수정).
- 타입 검사·변경 파일 린트·Webpack 프로덕션 빌드 통과. 로컬 migration 이력 일치 및 dry-run 적용 대기 없음 확인. 로컬 advisor는 기존 study/exploration의 복수 SELECT RLS 성능 경고 2건이며 새 보안 오류는 없다. 실제 브라우저 테스트는 수행하지 않았다.

운영 반영은 전체 UI 개선 배포 시 아래 순서로 진행한다. 아래 명령은 이번에 운영에 실행하지 않았다.

```bash
cd /Users/mealdm/Desktop/MEA/system
cat supabase/.temp/project-ref
npx supabase migration list --linked
npx supabase db push --linked --dry-run --skip-vault
```

연결된 운영 대상이 의도한 `epwlcallocdjkmgdmtlv`인지, 이력이 일치하는지 확인한다. 이번 예상 신규 migration은 `20261019083549_protect_referenced_learning_materials.sql` 하나다. **예상과 다른 migration이 나오면 적용 전에 이력·파일을 검토하고 중단한다.** 원격 reset이나 임의 migration repair로 맞추지 않는다.

```bash
npx supabase db push --linked --skip-vault
npx supabase migration list --linked
npx supabase db push --linked --dry-run --skip-vault
npm run build -- --webpack
```

적용 대기 없음을 확인한 뒤 앱을 기존 배포 절차로 배포한다(build만으로 배포되지는 않는다). 배포 후 테스트용 자료로 참조 중 삭제 차단·내용 수정·참조 제거 후 삭제를 확인한다. 실제 사용자 자료를 삭제해 검증하지 않는다. 운영 장기 성능 관찰/자동 경보를 이번에 구축한 것은 아니다.
