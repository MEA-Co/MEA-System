import { cookies } from 'next/headers';
import { z } from 'zod';

import { getViewRole } from '@/lib/admin';
import { getUserAccess } from '@/lib/auth';
import { STUDY_SIZE_ERROR } from '@/lib/study/payload-size';
import {
  confirmRequestSchema,
  REPORT_BUCKET,
  type StudyRow,
} from '@/lib/study/storage-model';
import { createClient } from '@/lib/supabase/server';

import { readStudyPage, readStudySummary } from '../list-page';

export const dynamic = 'force-dynamic';
const json = (body: unknown, status = 200) =>
  Response.json(body, {
    status,
    headers: { 'Cache-Control': 'private, no-store' },
  });
type Context = { params: Promise<{ path?: string[] }> };
async function handle(request: Request, context: Context) {
  const access = await getUserAccess();
  if (!access.user) return json({ error: '로그인이 필요합니다.' }, 401);
  if (
    !access.isOnboarded ||
    !['consultant', 'consultant_lead', 'admin'].includes(access.role ?? '')
  )
    return json({ error: '학습법 관리 권한이 없습니다.' }, 403);
  if (request.method !== 'GET') {
    const origin = request.headers.get('origin');
    if (origin && origin !== new URL(request.url).origin)
      return json({ error: '잘못된 요청입니다.' }, 403);
  }
  const viewRole = await getViewRole(access.role!);
  const ownOnly =
    new URL(request.url).searchParams.get('scope') === 'own' ||
    (viewRole !== 'admin' && viewRole !== 'consultant_lead');
  const referenceId = new URL(request.url).searchParams.get('reference');
  if (referenceId && !z.uuid().safeParse(referenceId).success)
    return json({ error: '잘못된 학습법 참조입니다.' }, 400);
  // Only explicit reference reads bypass the consultant's own-list filter.
  // Database RLS checks that this activity is linked by a visible guide answer.
  const referenceRead =
    !!referenceId &&
    access.role === 'consultant' &&
    new URL(request.url).searchParams.get('scope') !== 'own';
  const client = createClient(await cookies());
  const path = (await context.params).path ?? [];
  const id = path[0];
  if (id && !z.uuid().safeParse(id).success)
    return json({ error: '잘못된 경로입니다.' }, 404);
  if (
    request.method === 'POST' &&
    !id &&
    new URL(request.url).searchParams.get('mode') === 'table'
  ) {
    const result = await readStudyPage(
      client,
      new URL(request.url).searchParams,
      access.user.id,
      ownOnly,
      await request.json().catch(() => null),
    );
    return json(result.body, result.status);
  }
  if (request.method === 'GET' && !id) {
    const params = new URL(request.url).searchParams;
    if (params.get('mode') === 'table') {
      const result = await readStudyPage(
        client,
        params,
        access.user.id,
        ownOnly,
      );
      return json(result.body, result.status);
    }
    if (params.get('mode') === 'summary')
      return json(await readStudySummary(client, access.user.id, ownOnly));
    if (params.get('mode') === 'context')
      return json({ userId: access.user.id, activities: [] });
    if (referenceId) {
      let query = client
        .from('study')
        .select('*, owner:profiles!owner_id(name)')
        .is('deleted_at', null)
        .eq('id', referenceId);
      if (ownOnly && !referenceRead)
        query = query.eq('owner_id', access.user.id);
      const { data, error } = await query.maybeSingle();
      if (error) throw error;
      return json({ userId: access.user.id, activities: data ? [data] : [] });
    }
    // Default/reference pickers are bounded too; callers must follow page metadata.
    const result = await readStudyPage(client, params, access.user.id, ownOnly);
    return json(result.body, result.status);
  }
  if (request.method === 'GET' && path.length === 3 && path[1] === 'files') {
    let query = client
      .from('study')
      .select('reports')
      .eq('id', id)
      .is('deleted_at', null);
    if (ownOnly && access.role !== 'consultant')
      query = query.eq('owner_id', access.user.id);
    const { data, error } = await query.maybeSingle();
    if (error) return json({ error: '파일을 불러오지 못했습니다.' }, 503);
    const report = (data?.reports as StudyRow['reports'] | undefined)?.find(
      (r) => r.clientKey === path[2],
    );
    if (!report?.path)
      return json({ error: '첨부 파일을 찾을 수 없습니다.' }, 404);
    const result = await client.storage
      .from(REPORT_BUCKET)
      .createSignedUrl(report.path, 60, { download: report.name });
    return result.error
      ? json({ error: '다운로드 링크를 생성하지 못했습니다.' }, 503)
      : json({ url: result.data.signedUrl });
  }
  if (!id || path.length !== 1)
    return json({ error: '잘못된 경로입니다.' }, 404);
  const body = await request.json().catch(() => null);
  if (request.method === 'PUT') {
    const parsed = confirmRequestSchema.safeParse(body);
    if (!parsed.success || parsed.data.id !== id)
      return json(
        {
          error:
            !parsed.success &&
            parsed.error.issues.some(
              (issue) => issue.message === STUDY_SIZE_ERROR,
            )
              ? STUDY_SIZE_ERROR
              : '필수 항목과 첨부 파일을 확인해 주세요.',
        },
        400,
      );
    const d = parsed.data;
    const { data, error } = await client.rpc('save_study', {
      p_id: id,
      p_values: d.values,
      p_reports: d.reports,
      p_expected_revision: d.expectedRevision,
      p_save_id: d.saveId,
    });
    if (error) {
      const status =
        error.code === '42501'
          ? 403
          : ['40001', '23505'].includes(error.code)
            ? 409
            : ['22023', '22P02'].includes(error.code)
              ? 400
              : 503;
      return json(
        {
          error:
            status === 409
              ? '다른 곳에서 수정되었거나 삭제된 학습법입니다. 현재 입력을 임시저장한 뒤 목록의 최신 확정본을 확인해 주세요.'
              : status === 400
                ? '필수 항목 또는 첨부 파일 업로드를 확인해 주세요.'
                : '학습법을 확정하지 못했습니다. 다시 시도해 주세요.',
        },
        status,
      );
    }
    return json({ activity: data });
  }
  if (request.method === 'DELETE') {
    const parsed = z
      .object({ expectedRevision: z.number().int().positive() })
      .safeParse(body);
    if (!parsed.success)
      return json({ error: '삭제 정보를 확인해 주세요.' }, 400);
    const { data: before } = await client
      .from('study')
      .select('reports')
      .eq('id', id)
      .eq('owner_id', access.user.id)
      .maybeSingle();
    const { error } = await client.rpc('delete_study', {
      p_id: id,
      p_expected_revision: parsed.data.expectedRevision,
    });
    if (error?.code === 'MATERIAL_BUSY')
      return json(
        {
          code: 'MATERIAL_BUSY',
          error: '학습법이 다른 요청에서 처리 중입니다. 잠시 후 다시 시도해 주세요.',
        },
        409,
      );
    if (error?.code === 'MATERIAL_REFERENCED')
      return json(
        {
          code: 'MATERIAL_REFERENCED',
          error: '다른 곳에서 참조 중인 학습법은 삭제할 수 없습니다. 내용은 수정할 수 있습니다.',
        },
        409,
      );
    if (error)
      return json(
        {
          error:
            '삭제하지 못했습니다. 목록을 새로 불러와 변경 여부를 확인해 주세요.',
        },
        error.code === '40001' ? 409 : 403,
      );
    const paths = ((before?.reports ?? []) as StudyRow['reports']).flatMap(
      (r) => (r.path ? [r.path] : []),
    );
    const cleanup = paths.length
      ? await client.storage.from(REPORT_BUCKET).remove(paths)
      : null;
    return json({ ok: true, cleanupPending: !!cleanup?.error });
  }
  return json({ error: '지원하지 않는 요청입니다.' }, 405);
}
async function route(request: Request, context: Context) {
  try {
    return await handle(request, context);
  } catch {
    return json(
      { error: '요청을 처리하지 못했습니다. 입력 내용은 유지됩니다.' },
      503,
    );
  }
}
export { route as DELETE, route as GET, route as POST, route as PUT };
