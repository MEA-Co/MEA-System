"""Local Docker only: concurrent deletion/reference writes; remove synthetic fixtures."""
import json
import subprocess
import uuid
import time

COMMAND = ['docker', 'exec', '-i', 'supabase_db_system', 'psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1', '-U', 'postgres', '-d', 'postgres']


def sql(text):
    result = subprocess.run(COMMAND, input=text, text=True, capture_output=True, timeout=20)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout


def literal(value):
    return "'" + value.replace("'", "''") + "'"


def start_holder(text):
    process = subprocess.Popen(COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    process.stdin.write(text + "\n\\echo MATERIAL_LOCK_READY\nselect pg_sleep(2);\ncommit;\n")
    process.stdin.close()
    while True:
        line = process.stdout.readline()
        if 'MATERIAL_LOCK_READY' in line:
            return process
        if not line:
            raise RuntimeError(process.stderr.read())


for kind in ['study', 'exploration']:
    for first in ['reference', 'delete']:
        owner, target, unrelated, question, field = [str(uuid.uuid4()) for _ in range(5)]
        holder = None
        auth = f"select set_config('request.jwt.claim.sub','{owner}',false);"
        mention = '::mea-rich-text:v1::' + json.dumps({'type': 'doc', 'content': [{'type': 'paragraph', 'content': [{'type': 'text', 'text': 'test', 'marks': [{'type': kind + 'Reference', 'attrs': {'id': target}}]}]}]})
        write = f"update public.questions set prompt={literal(mention)} where id='{question}';"
        delete = f"select public.delete_{kind}('{target}',1);"
        try:
            sql(f"""begin;
insert into auth.users(id) values ('{owner}');
insert into public.profiles(id,role,name) values ('{owner}','consultant_lead','Local concurrency fixture');
insert into public.{kind}(id,owner_id,values,revision,save_id) values ('{target}','{owner}','{{}}',1,gen_random_uuid()), ('{unrelated}','{owner}','{{}}',1,gen_random_uuid());
{auth}
select public.save_question('{{"id":"{question}","title":"Concurrency fixture","prompt":"plain","fields":[{{"id":"{field}","label":"answer","kind":"text"}}],"rowMode":"single"}}',0,gen_random_uuid());
commit;""")
            holder = start_holder('begin;\n' + auth + (write if first == 'reference' else delete))
            started = time.monotonic()
            second = subprocess.run(COMMAND, input=auth + (delete if first == 'reference' else write), text=True, capture_output=True, timeout=15)
            elapsed = time.monotonic() - started
            assert second.returncode != 0 and 'MATERIAL_BUSY' in second.stderr, second.stderr
            assert elapsed < 1.5, f'Contended request waited {elapsed:.3f}s'
            # Another material must remain available while this lock is held.
            started = time.monotonic()
            sql(auth + f"select public.delete_{kind}('{unrelated}',1);")
            assert time.monotonic() - started < 1.5, 'Unrelated delete blocked'
            holder.wait(timeout=15)
            second = subprocess.run(COMMAND, input=auth + (delete if first == 'reference' else write), text=True, capture_output=True, timeout=15)
            assert holder.returncode == 0, holder.stderr.read()
            expected = 'MATERIAL_REFERENCED' if first == 'reference' else 'MATERIAL_UNAVAILABLE'
            assert second.returncode != 0 and expected in second.stderr, second.stderr
            state = sql(f"select deleted_at is not null from public.{kind} where id='{target}';").strip()
            assert state == ('f' if first == 'reference' else 't'), state
            print(f'PASS {kind}: {first} first; contention rejected in {elapsed * 1000:.1f}ms; unrelated delete unblocked; retry protected')
        finally:
            if holder and holder.poll() is None:
                holder.kill()
                holder.wait()
            sql(f"begin; delete from public.questions where id='{question}'; delete from public.{kind} where id in ('{target}','{unrelated}'); delete from auth.users where id='{owner}'; commit;")
