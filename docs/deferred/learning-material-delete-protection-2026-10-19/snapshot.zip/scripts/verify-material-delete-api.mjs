import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';

import ts from 'typescript';
import { z } from 'zod';

const id = 'c287a109-b732-4ab2-8a25-efad1fe25123';
for (const kind of ['study', 'exploration']) {
  for (const code of ['MATERIAL_REFERENCED', 'MATERIAL_BUSY', '40001', '42501', null]) {
    test(`${kind}: delete ${code ?? 'success'} preserves cleanup/error contract`, async () => {
      let cleanup = 0;
      let rpcCalls = 0;
      const client = {
        from(table) {
          assert.equal(table, kind);
          const query = {
            select(columns) { assert.equal(columns, 'reports'); return query; },
            eq() { return query; },
            async maybeSingle() { return { data: { reports: [{ path: 'fixture.pdf' }] } }; },
          };
          return query;
        },
        async rpc(name, args) {
          rpcCalls++;
          assert.equal(name, `delete_${kind}`);
          assert.equal(args.p_expected_revision, 3);
          return { error: code ? { code } : null };
        },
        storage: { from() { return { async remove() { cleanup++; return { error: null }; } }; } },
      };
      const imports = {
        'next/headers': { cookies: async () => ({}) },
        zod: { z },
        '@/lib/admin': { getViewRole: async () => 'consultant' },
        '@/lib/auth': { getUserAccess: async () => ({ user: { id }, isOnboarded: true, role: 'consultant' }) },
        '@/lib/supabase/server': { createClient: () => client },
        [`@/lib/${kind}/storage-model`]: { REPORT_BUCKET: 'reports' },
        [`@/lib/${kind}/payload-size`]: {},
        '../list-page': {},
      };
      const exports = {};
      vm.runInNewContext(ts.transpileModule(readFileSync(`app/api/${kind}/[[...path]]/route.ts`, 'utf8'), {
        compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
      }).outputText, { exports, require: (key) => {
        assert.ok(key in imports, key);
        return imports[key];
      }, Request, Response, URL });
      const response = await exports.DELETE(new Request(`http://localhost/api/${kind}/${id}`, {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expectedRevision: 3 }),
      }), { params: Promise.resolve({ path: [id] }) });
      const body = await response.json();
      assert.equal(rpcCalls, 1);
      assert.equal(response.status, !code ? 200 : code === '42501' ? 403 : 409);
      assert.equal(cleanup, code ? 0 : 1);
      if (code === 'MATERIAL_REFERENCED') {
        assert.equal(body.code, code);
        assert.match(body.error, /참조 중.*삭제할 수 없습니다.*수정할 수 있습니다/);
        assert.deepEqual(Object.keys(body).sort(), ['code', 'error']);
      }
    });
  }
}
