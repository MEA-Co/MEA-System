-- Generated from the verified local schema. Delete-only existence checks do not
-- expose other users' source content. Shared/exclusive transaction locks serialize
-- new reference writes with deletion; normal content edits remain allowed.
begin;
set local lock_timeout = '5s';
SET local check_function_bodies = off;

CREATE OR REPLACE FUNCTION private.guard_learning_material_reference_write()
  RETURNS TRIGGER
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO ''
  AS $function$
declare
  new_payload jsonb; old_payload jsonb; old_refs text[] := '{}'; ref text; available boolean;
begin
  new_payload := private.learning_material_source(tg_table_name,to_jsonb(new));
  if tg_op = 'UPDATE' then
    old_payload := private.learning_material_source(tg_table_name,to_jsonb(old));
    if new_payload is not distinct from old_payload then return new; end if;
    old_refs := private.learning_material_references(old_payload);
  end if;
  -- No full-table reads on save; inspect only this row and newly added targets.
  perform pg_catalog.pg_advisory_xact_lock_shared(741903, 1);
  for ref in select unnest(private.learning_material_references(new_payload)) except select unnest(old_refs) loop
    if split_part(ref,':',1) = 'study' then
      select exists(select 1 from public.study where id=split_part(ref,':',2)::uuid and deleted_at is null) into available;
    else
      select exists(select 1 from public.exploration where id=split_part(ref,':',2)::uuid and deleted_at is null) into available;
    end if;
    if not available then
      raise sqlstate 'PGRST' using message = '{"code":"MATERIAL_UNAVAILABLE","message":"Referenced material is no longer available","details":null,"hint":null}',
        detail = '{"status":409,"headers":{}}';
    end if;
  end loop;
  return new;
end;
$function$;

CREATE OR REPLACE FUNCTION private.guard_referenced_learning_material_delete()
  RETURNS TRIGGER
  LANGUAGE plpgsql
  SECURITY DEFINER
  SET search_path TO ''
  AS $function$
declare source_table text; payload jsonb; reference_key text;
begin
  if old.deleted_at is not null or new.deleted_at is null then return new; end if;
  perform pg_catalog.pg_advisory_xact_lock(741903, 1);
  reference_key := tg_table_name || ':' || old.id::text;
  -- The volatile trigger executes fresh queries after acquiring the lock, so a
  -- writer that committed while deletion waited is included at READ COMMITTED.
  foreach source_table in array array['questions','question_details','questionnaires','questionnaire_questions','question_responses','response_sessions','response_submissions'] loop
    for payload in execute format(
      'select private.learning_material_source(%L,to_jsonb(s)) from public.%I s where strpos(lower(private.learning_material_source(%L,to_jsonb(s))::text),$1)>0',
      source_table,source_table,source_table) using old.id::text
    loop
      if reference_key = any(private.learning_material_references(payload)) then
        raise sqlstate 'PGRST' using message = '{"code":"MATERIAL_REFERENCED","message":"Referenced material cannot be deleted","details":null,"hint":null}',
          detail = '{"status":409,"headers":{}}';
      end if;
    end loop;
  end loop;
  return new;
end;
$function$;

CREATE OR REPLACE FUNCTION private.learning_material_references (
  payload jsonb
)
  RETURNS text[]
  LANGUAGE plpgsql
  IMMUTABLE
  SET search_path TO ''
  AS $function$
declare
  refs text[] := '{}'; item jsonb; encoded text; material_id text; kind text;
begin
  if jsonb_typeof(payload) = 'string' then
    encoded := payload #>> '{}';
    if left(encoded,20) = '::mea-rich-text:v1::' then
      begin
        return private.learning_material_references(substr(encoded,21)::jsonb);
      exception when invalid_text_representation then return '{}';
      end;
    end if;
  elsif jsonb_typeof(payload) = 'array' then
    for item in select value from jsonb_array_elements(payload) loop
      refs := refs || private.learning_material_references(item);
    end loop;
  elsif jsonb_typeof(payload) = 'object' then
    kind := case payload->>'type' when 'studyReference' then 'study'
      when 'explorationReference' then 'exploration' end;
    material_id := payload->'attrs'->>'id';
    if kind is not null and material_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
      refs := array[kind || ':' || (material_id::uuid)::text];
    end if;
    for item in select value from jsonb_each(payload) loop
      refs := refs || private.learning_material_references(item);
    end loop;
  end if;
  return array(select distinct value from unnest(refs) value order by value);
end;
$function$;

CREATE OR REPLACE FUNCTION private.learning_material_source (
  table_name text,
  row_data   jsonb
)
  RETURNS jsonb
  LANGUAGE sql
  IMMUTABLE
  SET search_path TO ''
  AS $function$
  select case table_name
    when 'questions' then jsonb_build_array(row_data->'prompt',row_data->'fields',row_data->'condition',row_data->'response_requirements')
    when 'question_details' then row_data->'body'
    when 'questionnaires' then row_data->'start_notice'
    when 'questionnaire_questions' then jsonb_build_array(row_data->'body',row_data->'options')
    when 'question_responses' then jsonb_build_array(row_data->'rows',row_data->'legacy_answer',row_data->'previous_responses',row_data->'legacy_definition')
    when 'response_sessions' then jsonb_build_array(row_data->'layout',row_data->'free_response',row_data->'legacy_response')
    when 'response_submissions' then row_data->'answers'
    else 'null'::jsonb end;
$function$;

CREATE TRIGGER protect_referenced_exploration
  BEFORE UPDATE OF deleted_at ON public.exploration
  FOR EACH ROW
  WHEN (((old.deleted_at IS NULL) AND (new.deleted_at IS NOT NULL)))
  EXECUTE FUNCTION private.guard_referenced_learning_material_delete();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.question_details
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.question_responses
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.questionnaire_questions
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.questionnaires
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.questions
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.response_sessions
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_learning_material_references
  BEFORE INSERT OR UPDATE ON public.response_submissions
  FOR EACH ROW
  EXECUTE FUNCTION private.guard_learning_material_reference_write();

CREATE TRIGGER protect_referenced_study
  BEFORE UPDATE OF deleted_at ON public.study
  FOR EACH ROW
  WHEN (((old.deleted_at IS NULL) AND (new.deleted_at IS NOT NULL)))
  EXECUTE FUNCTION private.guard_referenced_learning_material_delete();

REVOKE ALL ON FUNCTION "private"."guard_learning_material_reference_write"() FROM PUBLIC;

GRANT EXECUTE ON FUNCTION "private"."guard_learning_material_reference_write"() TO "postgres";

REVOKE ALL ON FUNCTION "private"."guard_referenced_learning_material_delete"() FROM PUBLIC;

GRANT EXECUTE ON FUNCTION "private"."guard_referenced_learning_material_delete"() TO "postgres";

REVOKE ALL ON FUNCTION "private"."learning_material_references"(jsonb) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION "private"."learning_material_references"(jsonb) TO "postgres";

REVOKE ALL ON FUNCTION "private"."learning_material_source"(text, jsonb) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION "private"."learning_material_source"(text, jsonb) TO "postgres";


-- Explicitly override grants even where environment default privileges differ.
revoke all on function private.learning_material_references(jsonb),
 private.learning_material_source(text,jsonb),
 private.guard_learning_material_reference_write(),
 private.guard_referenced_learning_material_delete() from public,anon,authenticated;
commit;
