begin;
set local lock_timeout='5s';
-- One-time backfill runs only at deployment. Freeze source writes until the
-- ledger and its maintenance triggers become visible together.
lock table public.questions,public.question_details,public.questionnaires,
 public.questionnaire_questions,public.question_responses,public.response_sessions,
 public.response_submissions,public.study,public.exploration in share row exclusive mode;

create table private.learning_material_links (
 source_table text not null check(source_table in ('questions','question_details','questionnaires','questionnaire_questions','question_responses','response_sessions','response_submissions')),
 source_id uuid not null,
 material_kind text not null check(material_kind in ('study','exploration')),
 material_id uuid not null,
 primary key(source_table,source_id,material_kind,material_id)
);
alter table private.learning_material_links enable row level security;
revoke all on table private.learning_material_links from public,anon,authenticated;
create index learning_material_links_target_idx on private.learning_material_links(material_kind,material_id);

-- Reuse the reviewed parser; store only relationships, never answer contents.
do $$ declare source_table text; id_column text; begin
 foreach source_table in array array['questions','question_details','questionnaires','questionnaire_questions','question_responses','response_sessions','response_submissions'] loop
  id_column:=case source_table when 'response_submissions' then 'session_id' else 'id' end;
  execute format('insert into private.learning_material_links select %L,s.%I,split_part(ref,'':'',1),split_part(ref,'':'',2)::uuid from public.%I s cross join lateral unnest(private.learning_material_references(private.learning_material_source(%L,to_jsonb(s)))) ref',source_table,id_column,source_table,source_table);
 end loop;
end $$;

create or replace function private.guard_learning_material_reference_write()
returns trigger language plpgsql security definer set search_path='' as $$
declare
 new_payload jsonb; source_id_value uuid; old_refs text[]; new_refs text[]; ref text; available boolean;
begin
 if tg_op='DELETE' then
  source_id_value:=(to_jsonb(old)->>case tg_table_name when 'response_submissions' then 'session_id' else 'id' end)::uuid;
  delete from private.learning_material_links where source_table=tg_table_name and source_id=source_id_value;
  return old;
 end if;
 new_payload:=private.learning_material_source(tg_table_name,to_jsonb(new));
 if tg_op='UPDATE' and new_payload is not distinct from private.learning_material_source(tg_table_name,to_jsonb(old)) then return new; end if;
 source_id_value:=(to_jsonb(new)->>case tg_table_name when 'response_submissions' then 'session_id' else 'id' end)::uuid;
 new_refs:=private.learning_material_references(new_payload);
 select coalesce(array_agg(material_kind||':'||material_id::text order by material_kind,material_id),'{}')
 into old_refs from private.learning_material_links where source_table=tg_table_name and source_id=source_id_value;
 if new_refs=old_refs then return new; end if;
 -- Per-target non-blocking shared locks, not a global lock. Existing refs are
 -- already protected by the ledger; only new targets need existence checks.
 for ref in select unnest(new_refs) except select unnest(old_refs) order by 1 loop
  if not pg_catalog.pg_try_advisory_xact_lock_shared(pg_catalog.hashtextextended('learning-material:'||ref,0)) then
   raise sqlstate 'PGRST' using message='{"code":"MATERIAL_BUSY","message":"Material is being changed; try again","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
  end if;
  if split_part(ref,':',1)='study' then
   select exists(select 1 from public.study where id=split_part(ref,':',2)::uuid and deleted_at is null) into available;
  else
   select exists(select 1 from public.exploration where id=split_part(ref,':',2)::uuid and deleted_at is null) into available;
  end if;
  if not available then
   raise sqlstate 'PGRST' using message='{"code":"MATERIAL_UNAVAILABLE","message":"Referenced material is no longer available","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
  end if;
  insert into private.learning_material_links(source_table,source_id,material_kind,material_id)
   values(tg_table_name,source_id_value,split_part(ref,':',1),split_part(ref,':',2)::uuid);
 end loop;
 delete from private.learning_material_links where source_table=tg_table_name and source_id=source_id_value
  and not (material_kind||':'||material_id::text)=any(new_refs);
 return new;
end;
$$;

create or replace function private.guard_referenced_learning_material_delete()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if old.deleted_at is not null or new.deleted_at is null then return new; end if;
 if not pg_catalog.pg_try_advisory_xact_lock(pg_catalog.hashtextextended('learning-material:'||tg_table_name||':'||old.id::text,0)) then
  raise sqlstate 'PGRST' using message='{"code":"MATERIAL_BUSY","message":"Material is being changed; try again","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
 end if;
 -- One indexed existence lookup, independent of source answer sizes.
 if exists(select 1 from private.learning_material_links where material_kind=tg_table_name and material_id=old.id) then
  raise sqlstate 'PGRST' using message='{"code":"MATERIAL_REFERENCED","message":"Referenced material cannot be deleted","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
 end if;
 return new;
end;
$$;

do $$ declare source_table text; begin
 foreach source_table in array array['questions','question_details','questionnaires','questionnaire_questions','question_responses','response_sessions','response_submissions'] loop
  execute format('drop trigger protect_learning_material_references on public.%I',source_table);
  execute format('create trigger protect_learning_material_references after insert or update or delete on public.%I for each row execute function private.guard_learning_material_reference_write()',source_table);
 end loop;
end $$;

-- The original delete RPC acquires its own material lock before the trigger.
-- Make those two acquisitions non-blocking too; retain all auth, revision,
-- idempotence and existing PGRST/40001 business-conflict behavior verbatim.
do $$ declare kind text; definition text; needle text; begin
 foreach kind in array array['study','exploration'] loop
  definition:=pg_get_functiondef(format('private.delete_%s(uuid,integer)',kind)::regprocedure);
  needle:='perform pg_advisory_xact_lock(hashtextextended(p_id::text,0));';
  if strpos(definition,needle)=0 then raise exception 'Unexpected delete lock: %',kind; end if;
  definition:=replace(definition,needle,$replacement$
 if not pg_catalog.pg_try_advisory_xact_lock(pg_catalog.hashtextextended(p_id::text,0)) then
  raise sqlstate 'PGRST' using message='{"code":"MATERIAL_BUSY","message":"Material is being changed; try again","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
 end if;
$replacement$);
  needle:=format('select * into v from public.%s where id=p_id for update;',kind);
  if strpos(definition,needle)=0 then raise exception 'Unexpected delete row lock: %',kind; end if;
  definition:=replace(definition,needle,format($replacement$
 begin
  select * into v from public.%I where id=p_id for update nowait;
 exception when lock_not_available then
  raise sqlstate 'PGRST' using message='{"code":"MATERIAL_BUSY","message":"Material is being changed; try again","details":null,"hint":null}',detail='{"status":409,"headers":{}}';
 end;
$replacement$,kind));
  execute definition;
 end loop;
end $$;
revoke all on function private.guard_learning_material_reference_write(),private.guard_referenced_learning_material_delete() from public,anon,authenticated;
commit;
