-- Synthetic fixtures only, entirely rolled back. No browser/production access.
begin;
create temp table material_fixture as select gen_random_uuid() owner_id,gen_random_uuid() other_id,
 gen_random_uuid() study_id,gen_random_uuid() exploration_id,gen_random_uuid() question_id,
 gen_random_uuid() questionnaire_id,gen_random_uuid() section_id,gen_random_uuid() session_id;
insert into auth.users(id) select owner_id from material_fixture union all select other_id from material_fixture;
insert into public.profiles(id,role,name) select owner_id,'consultant_lead','삭제 보호 작성자' from material_fixture
 union all select other_id,'consultant','비공개 응답자' from material_fixture;
grant select on material_fixture to authenticated;
select set_config('request.jwt.claim.sub',(select owner_id::text from material_fixture),true);
set local role authenticated;
select public.save_study(study_id,'{"category":"내신","problemSource":"self","subject":"수학","customSubject":"","resultDiagnosis":"","references":[],"problem":"문제","strategy":"전략","practiceGuide":"가이드","practicePeriod":"2주","checklist":"확인","followup":"후속"}', '[]',0,gen_random_uuid()) from material_fixture;
select public.save_exploration(exploration_id,'{"grade":"1","semester":"1","recordType":"세특","recordArea":"수학","schoolContext":"수업","topic":"주제","record":"기록","competencies":"역량","motivation":"동기","story":"과정","result":"결과","followup":"","references":[]}', '[]',0,gen_random_uuid()) from material_fixture;
select public.save_question(jsonb_build_object('id',question_id,'title','보호 검증','prompt','본문','fields',jsonb_build_array(jsonb_build_object('id',gen_random_uuid(),'label','답변','kind','text')),'rowMode','single'),0,gen_random_uuid()) from material_fixture;
reset role;
create function pg_temp.mention(kind text, id uuid) returns text language sql as $$
 select '::mea-rich-text:v1::'||jsonb_build_object('type','doc','content',jsonb_build_array(jsonb_build_object('type','paragraph','content',jsonb_build_array(jsonb_build_object('type','text','text','참조','marks',jsonb_build_array(jsonb_build_object('type',kind||'Reference','attrs',jsonb_build_object('id',upper(id::text)))))))))::text;
$$;
create function pg_temp.assert_blocked() returns void language plpgsql as $$
declare f record; kind text; item_id uuid; rev int; details text;
begin
 select * into f from material_fixture;
 foreach kind in array array['study','exploration'] loop
  item_id:=case kind when 'study' then f.study_id else f.exploration_id end;
  execute format('select revision from public.%I where id=$1',kind) into rev using item_id;
  begin
   execute format('select public.delete_%I($1,$2)',kind) using item_id,rev;
   raise exception 'Referenced % deleted',kind;
  exception when sqlstate 'PGRST' then
   get stacked diagnostics details=PG_EXCEPTION_DETAIL;
   if sqlerrm::jsonb->>'code'<>'MATERIAL_REFERENCED' or details::jsonb->>'status'<>'409' then raise; end if;
  end;
  if exists(select 1 from public.study where id=item_id and (deleted_at is not null or values='{}'))
    or exists(select 1 from public.exploration where id=item_id and (deleted_at is not null or values='{}')) then raise exception 'Blocked delete modified content'; end if;
 end loop;
end;
$$;
create temp table material_text as select
 '::mea-rich-text:v1::'||jsonb_build_object('type','doc','content',
 (substr(pg_temp.mention('study',study_id),21)::jsonb->'content') ||
 (substr(pg_temp.mention('exploration',exploration_id),21)::jsonb->'content'))::text combined,
 jsonb_build_array(pg_temp.mention('study',study_id),pg_temp.mention('exploration',exploration_id)) reference_values from material_fixture;
-- Parser: nested serialization, upper-case IDs, duplicates, malformed/plain text.
do $$ declare f record; refs text[]; begin
 select * into f from material_fixture;
 refs:=private.learning_material_references(jsonb_build_object('a',pg_temp.mention('study',f.study_id),'b',pg_temp.mention('exploration',f.exploration_id)));
 if cardinality(refs)<>2 or not ('study:'||f.study_id)=any(refs) then raise exception 'Parser failed'; end if;
 if cardinality(private.learning_material_references(to_jsonb(f.study_id::text)))<>0
 or cardinality(private.learning_material_references(to_jsonb('::mea-rich-text:v1::{broken'::text)))<>0 then raise exception 'False reference'; end if;
 if has_function_privilege('authenticated','private.learning_material_references(jsonb)','execute')
 or has_function_privilege('anon','private.guard_referenced_learning_material_delete()','execute') then raise exception 'Helper ACL exposed'; end if;
end $$;
-- Each durable source is independently sufficient to protect both materials.
update public.questions set prompt=(select combined from material_text) where id=(select question_id from material_fixture);
select pg_temp.assert_blocked();
-- Editing a referenced material through its real RPC is still allowed.
set local role authenticated;
select public.save_study(s.id,s.values||'{"strategy":"수정 가능"}',s.reports,s.revision,gen_random_uuid()) from public.study s join material_fixture f on f.study_id=s.id;
select public.save_exploration(e.id,e.values||'{"topic":"수정 가능"}',e.reports,e.revision,gen_random_uuid()) from public.exploration e join material_fixture f on f.exploration_id=e.id;
reset role;
update public.questions set prompt='본문',fields=jsonb_set(fields,'{0,label}','"답변"') where id=(select question_id from material_fixture);
insert into public.question_details(id,question_id,position,title,body) select gen_random_uuid(),question_id,0,'설명',pg_temp.mention('study',study_id) from material_fixture;
insert into public.question_details(id,question_id,position,title,body) select gen_random_uuid(),question_id,1,'설명',pg_temp.mention('exploration',exploration_id) from material_fixture;
select pg_temp.assert_blocked();
delete from public.question_details where question_id=(select question_id from material_fixture);
insert into public.questionnaires(id,title,created_by,start_notice) select questionnaire_id,'검증',owner_id,jsonb_build_object('title','안내','body',pg_temp.mention('study',study_id),'buttonLabel','') from material_fixture;
update public.questionnaires set start_notice=jsonb_set(start_notice,'{body}',to_jsonb((select combined from material_text))) where id=(select questionnaire_id from material_fixture);
select pg_temp.assert_blocked();
update public.questionnaires set start_notice=null where id=(select questionnaire_id from material_fixture);
insert into public.questionnaire_sections(id,questionnaire_id,title,position) select section_id,questionnaire_id,'섹션',0 from material_fixture;
insert into public.questionnaire_questions(questionnaire_id,section_id,body,position) select questionnaire_id,section_id,pg_temp.mention('study',study_id),0 from material_fixture;
insert into public.questionnaire_questions(questionnaire_id,section_id,body,position) select questionnaire_id,section_id,pg_temp.mention('exploration',exploration_id),1 from material_fixture;
select pg_temp.assert_blocked();
delete from public.questionnaire_questions where questionnaire_id=(select questionnaire_id from material_fixture);
insert into public.response_sessions(id,respondent_id,origin_questionnaire_id,started_role,started_stage,layout) select session_id,other_id,questionnaire_id,'consultant','published',reference_values from material_fixture cross join material_text;
select pg_temp.assert_blocked();
delete from public.response_sessions where id=(select session_id from material_fixture);
insert into public.response_sessions(id,respondent_id,origin_questionnaire_id,started_role,started_stage) select session_id,other_id,questionnaire_id,'consultant','published' from material_fixture;
insert into public.question_responses(session_id,question_id,rows) select session_id,question_id,jsonb_build_array(jsonb_build_object('id',gen_random_uuid(),'answers',jsonb_build_object('a',pg_temp.mention('study',study_id),'b',pg_temp.mention('exploration',exploration_id)))) from material_fixture;
-- Owner cannot read other user's working answers, but the real delete RPC still blocks.
set local role authenticated;
do $$ begin
 if exists(select 1 from public.question_responses where session_id=(select session_id from material_fixture)) then raise exception 'Private response exposed'; end if;
 perform pg_temp.assert_blocked();
end $$;
reset role;
insert into public.response_submissions(session_id,answers,revision) select session_id,jsonb_build_object(question_id::text,jsonb_build_object('rows',rows)),1 from public.question_responses where session_id=(select session_id from material_fixture);
update public.question_responses set rows='[]' where session_id=(select session_id from material_fixture);
select pg_temp.assert_blocked();
delete from public.response_submissions where session_id=(select session_id from material_fixture);
-- Idempotency copies are not durable references and must not permanently block deletion.
update public.response_sessions set last_payload=jsonb_build_object('answers',(select reference_values from material_text)) where id=(select session_id from material_fixture);
-- Plain UUID text does not count as a link.
update public.questions set prompt=(select study_id::text||' '||exploration_id::text from material_fixture) where id=(select question_id from material_fixture);
set local role authenticated;
select public.delete_study(s.id,s.revision) from public.study s join material_fixture f on s.id=f.study_id;
select public.delete_exploration(e.id,e.revision) from public.exploration e join material_fixture f on e.id=f.exploration_id;
reset role;
do $$ declare f record; kind text; target uuid; begin
 select * into f from material_fixture;
 foreach kind in array array['study','exploration'] loop
  target:=case kind when 'study' then f.study_id else f.exploration_id end;
  begin
   update public.questions set prompt=pg_temp.mention(kind,target) where id=f.question_id;
   raise exception 'New reference to deleted material accepted';
  exception when sqlstate 'PGRST' then
   if sqlerrm::jsonb->>'code'<>'MATERIAL_UNAVAILABLE' then raise; end if;
  end;
 end loop;
end $$;
-- Ledger must be private and consistent after all reference removals.
do $$ begin
 if has_table_privilege('authenticated','private.learning_material_links','select')
 or has_table_privilege('anon','private.learning_material_links','insert') then raise exception 'Ledger exposed'; end if;
 if exists(select 1 from private.learning_material_links where material_id in
  (select study_id from material_fixture union all select exploration_id from material_fixture)) then raise exception 'Stale ledger'; end if;
end $$;
rollback;
